g++ main.cpp \
-framework opengl \
-lGLEW \
-lglfw3 \
-framework IOKit \
-framework CoreVideo \
-framework Cocoa \
-o test
